<?php
/*
Template Name: My Custom Page
*/
?>

<?php

    $post = get_post($_POST['id']);
	if ($post) :
		setup_postdata($post);
?>
<section class="ajax-content-sect">
	<div class="container-fluid">
    	<div class="row">
            <div class="col-md-4 text-center">
                <?php the_post_thumbnail('large',array('class'=>'img-fluid')) ?>
            </div>
            <div class="col-md-8 sh-content">
                <?php the_content(); ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>