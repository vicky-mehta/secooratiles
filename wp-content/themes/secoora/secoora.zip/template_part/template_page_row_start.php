<?php if ( is_post_type_archive('product') ) : ?>
<section class="main_sec">
<?php else : ?>
<section class="main_sec">
<?php endif; ?>
	<div class="container">
    	<div class="row">